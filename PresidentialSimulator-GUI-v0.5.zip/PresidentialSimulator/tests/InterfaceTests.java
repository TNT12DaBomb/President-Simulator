import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public final class InterfaceTests {
 private static int checks;
 private static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 private static CareerEngine game(){return new CareerEngine(71,President.Difficulty.NORMAL,President.RunningMate.FUNDRAISER,GameRules.CURRENT);}
 private static CareerEngine debate(){var e=game();while(e.view().campaign().turnsUsed()<4){if(e.view().campaign().pendingEvent()!=null)e.submit(CareerCommand.campaign(GameCommand.respond(1)));else e.submit(CareerCommand.campaign(GameCommand.rest()));}return e;}
 private static String run(Path save,String commands,int width,int height){var bytes=new ByteArrayOutputStream();new TextUI(new ByteArrayInputStream(commands.getBytes(StandardCharsets.UTF_8)),new PrintStream(bytes,true,StandardCharsets.UTF_8),71,save,false,false,new TerminalScreen.Options(width,height,false,false)).run();return bytes.toString(StandardCharsets.UTF_8);}
 private static void await(ByteArrayOutputStream bytes,String wanted)throws Exception{long end=System.nanoTime()+5_000_000_000L;while(!bytes.toString(StandardCharsets.UTF_8).contains(wanted)&&System.nanoTime()<end)Thread.sleep(20);check(bytes.toString(StandardCharsets.UTF_8).contains(wanted),"Rendered "+wanted);}
 public static void main(String[]args)throws Exception{
  Path dir=Files.createTempDirectory("interface"),save=dir.resolve("career.save");
  try{
   String help=run(save,"3\n1\n\n2\n\n3\n\n4\n\n5\n\n0\n0\n",100,28);
   for(String topic:List.of("START HERE","CAMPAIGNS & DEBATES","RUNNING THE PRESIDENCY","CLOCKS, CONTROLS & STATISTICS","SAVES & EXIT"))check(help.contains(topic),"Title help topic "+topic);
   check(!Files.exists(save),"Help never creates a career or save");check(!help.contains("Import Governance")&&!help.contains("legacy"),"Help no longer advertises old profiles");
   String created=run(save,"?\n0\n1\n1\n3\n\n0\n3\n1\n\n0\n",100,28);check(Files.exists(save)&&CareerSave.read(save).rules()==GameRules.CURRENT,"New player can create a current career");check(created.contains("START HERE")&&created.contains("CAMPAIGN"),"Help works from both title and game menu");
   String invalid=run(save,"2\n1\n\nwrong\nwrong\nwrong\n",100,28);check(invalid.contains("Please type a number"),"Invalid input explained");
   var e=debate();CareerSave.write(e,save);String decision=run(save,"2\n1\n\n1\n2\n1\n1\n1\n1\n1\n",100,28);check(decision.contains("Debate preparation"),"Preparation renders");check(!decision.contains("\033"),"Plain debate ANSI-free");

   CareerSave.write(game(),save);String saved=run(save,"2\n1\n\n0\n1\n2\n1\nFirst run\n\n",100,28);Path slot=dir.resolve("slot-1.save");check(Files.exists(slot)&&CareerSave.metadata(slot).label().equals("First run"),"First player can name a manual slot");check(saved.contains("Named save written."),"Manual-save success is visible before leaving screen");String resumed=run(save,"2\n2\n1\n\n",100,28);check(resumed.contains("Career restored."),"Manual slot loads through guided menu");
   var office=game();office.submit(CareerCommand.dev(CareerCommand.DeveloperAction.FORCE_WIN));office.submit(CareerCommand.advance());office.submit(CareerCommand.advance());
   String[] routes={"1\n0\n","2\n0\n","3\n0\n","4\n0\n","5\n0\n","?\n3\n\n0\n","ST\n2\n\n"};
   for(String route:routes){CareerSave.write(office,save);String rendered=run(save,"2\n1\n\n"+route,100,28);check(rendered.contains("PRESIDENTIAL DESK"),"Office navigation returns to desk");check(CareerSave.read(save).view().equals(office.view()),"Browsing office menus spends no actions");}
   CareerSave.write(office,save);String monthly=run(save,"2\n1\n\n6\n1\n\n",100,28);check(CareerSave.read(save).view().termMonths()==1,"End month confirmation advances exactly once");check(monthly.contains("CHAPTER UPDATE"),"Month result shown");
   // Every word of long headers/descriptions survives rendering on a small supported terminal.
   var bytes=new ByteArrayOutputStream();var screen=new TerminalScreen(new PrintStream(bytes,true,StandardCharsets.UTF_8),new TerminalScreen.Options(60,20,false,false));String heading="A complete question title that is deliberately longer than a narrow screen can fit on one line END-TITLE";String description="Full explanation "+"important details ".repeat(50)+"END-DESCRIPTION";screen.begin(heading,"All status values also remain visible even on narrower supported screens END-STATUS");screen.content().println(description);screen.render(0,"Choose");int pages=screen.pages();for(int i=1;i<pages;i++)screen.render(i,"Choose");String narrow=bytes.toString(StandardCharsets.UTF_8);check(narrow.contains("END-TITLE")&&narrow.contains("END-STATUS")&&narrow.contains("END-DESCRIPTION"),"Full text retained across pages");check(!narrow.contains("..."),"Renderer never ellipsizes descriptions");for(String line:narrow.split("\\R"))check(line.length()<=60,"Rendered lines respect small width");
   // Current save slots and backups; older formats rejected without overwriting them.
   CareerSave.write(game(),save,"My career");CareerSave.write(game(),save);check(Files.exists(CareerSave.backup(save,1)),"Backup created");check(CareerSave.metadata(save).label().equals("My career"),"Save label retained");var properties=new Properties();try(var in=Files.newInputStream(save)){properties.load(in);}properties.setProperty("format","presidency-debates-v1");Path old=dir.resolve("old.save");try(var out=Files.newOutputStream(old)){properties.store(out,"old fixture");}byte[] before=Files.readAllBytes(old);boolean rejected=false;try{CareerSave.read(old);}catch(IOException ex){rejected=ex.getMessage().contains("older saves");}check(rejected&&Arrays.equals(before,Files.readAllBytes(old)),"Old save rejected and left untouched");
   // Actual live ticks, not just a static 60s label. Help pauses; leaving help resumes automatically.
   e=debate();e.submit(CareerCommand.campaign(GameCommand.respond(1)));e.submit(CareerCommand.campaign(GameCommand.tick(9)));CareerSave.write(e,save);
   bytes=new ByteArrayOutputStream();final var capture=bytes;var writer=new PipedOutputStream();var input=new PipedInputStream(writer);var failure=new java.util.concurrent.atomic.AtomicReference<Throwable>();
   Thread ui=new Thread(()->{try{new TextUI(input,new PrintStream(capture,true,StandardCharsets.UTF_8),71,save,false,false,new TerminalScreen.Options(100,28,true,false)).run();}catch(Throwable ex){failure.set(ex);}});ui.setDaemon(true);ui.start();
   try{writer.write("2\n1\n\n?\n".getBytes(StandardCharsets.UTF_8));writer.flush();await(capture,"HOW TO PLAY");Thread.sleep(3200);check(!capture.toString(StandardCharsets.UTF_8).contains("Time expired."),"Help pauses beyond remaining deadline");writer.write("0\n".getBytes(StandardCharsets.UTF_8));writer.flush();await(capture,"Time left:  2s");await(capture,"Time left:  1s");await(capture,"Time expired.");check(CareerSave.read(save).view().campaign().pendingEvent().title().contains("fact check"),"Expiry without Enter advances and saves next question");}finally{writer.close();ui.join(4000);}check(!ui.isAlive()&&failure.get()==null,"EOF cleanly saves and exits");check(capture.toString(StandardCharsets.UTF_8).contains("\033[?1049l"),"Full screen is restored on exit");
  }finally{try(var paths=Files.list(dir)){for(var f:paths.toList())Files.delete(f);}Files.delete(dir);}
  System.out.println("InterfaceTests: "+checks+" checks passed.");
 }
}
